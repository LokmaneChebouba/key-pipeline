# sif_parser_lextab.py. This file automatically created by PLY (version 3.3). Don't edit!
_tabversion   = '3.3'
_lextokens    = {'IDENT': 1, 'NOT': 1, 'AND': 1, 'LB': 1, 'RB': 1, 'PLUS': 1, 'MINUS': 1}
_lexreflags   = 0
_lexliterals  = ''
_lexstateinfo = {'INITIAL': 'inclusive'}
_lexstatere   = {'INITIAL': [('(?P<t_newline>\\n+)|(?P<t_IDENT>[a-zA-Z][a-zA-Z0-9_:\\-\\[\\]/]*)|(?P<t_LB>\\()|(?P<t_MINUS>-1)|(?P<t_RB>\\))|(?P<t_AND>&)|(?P<t_NOT>!)|(?P<t_PLUS>1)', [None, ('t_newline', 'newline'), (None, 'IDENT'), (None, 'LB'), (None, 'MINUS'), (None, 'RB'), (None, 'AND'), (None, 'NOT'), (None, 'PLUS')])]}
_lexstateignore = {'INITIAL': ' \t'}
_lexstateerrorf = {'INITIAL': 't_error'}
